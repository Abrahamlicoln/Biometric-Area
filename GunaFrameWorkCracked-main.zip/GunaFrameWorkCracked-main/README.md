# GunaFrameWorkCracked
Latest Guna.UI2 FrameWork cracked by Cabbo!

# Crack

Latest Guna.UI2 FrameWork version [2.0.3.5] cracked. Working as 10/11/2022, and tested with .NET FrameWork 4.7.2 and 4.8.1

# How to use it

Replace the new Guna.UI2.DLL in your Directory: ProjectName\packages\Guna.UI2.WinForms.2.0.3.5\lib\net40\Guna.UI2.DLL

Enjoy.

# Do you want to contact me?

Discord: FreeCabbo10#6558

Telegram: https://t.me/cabboshiba
